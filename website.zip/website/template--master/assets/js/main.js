/*===== MENU SHOW =====*/ 
const showMenu = (toggleId, navId) =>{
    const toggle = document.getElementById(toggleId),
    nav = document.getElementById(navId)

    if(toggle && nav){
        toggle.addEventListener('click', ()=>{
            nav.classList.toggle('show')
        })
    }
}
showMenu('nav-toggle','nav-menu')

/*===== ACTIVE AND REMOVE MENU =====*/
const navLink = document.querySelectorAll('.nav__link');   

function linkAction(){
  /*Active link*/
  navLink.forEach(n => n.classList.remove('active'));
  this.classList.add('active');
  
  /*Remove menu mobile*/
  const navMenu = document.getElementById('nav-menu')
  navMenu.classList.remove('show')
}
navLink.forEach(n => n.addEventListener('click', linkAction));



function scrolling(){
  var aboutImage = document.querySelector('.about__img');
  var AboutPosition = aboutImage.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3;
  if(AboutPosition < scrolPosition){
    aboutImage.classList.add('about__appear');
  }
}
window.addEventListener('scroll',scrolling);

function scrollingtext(){
  var text = document.querySelector('.text');
  var textPosition = text.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 2;
  if(textPosition < scrolPosition){
    text.classList.add('text__appear');
  }
}
window.addEventListener('scroll',scrollingtext);

function scrollingskills(){
  var skills = document.querySelector('.skills__img');
  var skillsPosition = skills.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 2;
  if(skillsPosition < scrolPosition){
    skills.classList.add('skills__appear');
  }
}
window.addEventListener('scroll',scrollingskills);

function scrollingskillstext(){
  var skillsText = document.querySelector('.skills__text');
  var skillsPosition = skillsText.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3;
  if(skillsPosition < scrolPosition){
    skillsText.classList.add('skills__appear');
  }
}
window.addEventListener('scroll',scrollingskillstext);

function scrollingWork(){
  var workSec = document.querySelector('.work__sec');
  var workPosition = workSec.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3;
  if(workPosition < scrolPosition){
    workSec.classList.add('worksec__appear');
  }
}
window.addEventListener('scroll',scrollingWork);


function scrollingContact(){
  var contactSec = document.querySelector('.contact__sec');
  var contactPosition = contactSec.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3.4;
  if(contactPosition < scrolPosition){
    contactSec.classList.add('contactsec__appear');
  }
}
window.addEventListener('scroll',scrollingContact);

function scrollingHome(){
  var Home = document.querySelector('.home__data');
  var homePosition = Home.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3.4;
  if(homePosition < scrolPosition){
    Home.classList.add('homedata__appear');
  }
}
window.addEventListener('load',scrollingHome);

function scrollingImage(){
  var Homeimg = document.querySelector('.home__img');
  var homePosition = Homeimg.getBoundingClientRect().top;
  var scrolPosition = window.innerHeight  / 3.4;
  if(homePosition < scrolPosition){
    Homeimg.classList.add('homeimg__appear');
  }
}
window.addEventListener('load',scrollingImage);
